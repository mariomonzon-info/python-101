from abc import ABC, abstractmethod
from modelos.factura import Factura

class IExportador(ABC):
    @abstractmethod
    def exportar(self, factura: Factura) -> None:
        pass
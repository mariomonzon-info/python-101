from abc import ABC, abstractmethod
from modelos.factura import Factura

class IEstrategiaDescuento(ABC):
    @abstractmethod
    def aplicar(self, factura: Factura) -> float:
        pass
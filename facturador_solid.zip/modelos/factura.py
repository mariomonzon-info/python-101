from dataclasses import dataclass
from typing import List

@dataclass
class Item:
    nombre: str
    cantidad: int
    precio_unitario: float

@dataclass
class Factura:
    cliente: str
    items: List[Item]
    total: float
    descuento: float
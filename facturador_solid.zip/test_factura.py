import unittest
from modelos.factura import Item
from servicios.generador import GeneradorFactura
from servicios.descuento import SinDescuento

class TestFactura(unittest.TestCase):
    def test_factura_sin_descuento(self):
        items = [Item("Producto", 2, 100)]
        gen = GeneradorFactura(SinDescuento())
        factura = gen.generar("Cliente", items)
        self.assertEqual(factura.total, 200)
        self.assertEqual(factura.descuento, 0)

if __name__ == '__main__':
    unittest.main()
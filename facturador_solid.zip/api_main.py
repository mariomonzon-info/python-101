from fastapi import FastAPI
from routers import factura

app = FastAPI(title="Facturador SOLID API")

app.include_router(factura.router)
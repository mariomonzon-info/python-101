from fastapi import APIRouter
from modelos.factura import Item
from servicios.generador import GeneradorFactura
from servicios.descuento import DescuentoVIP
from typing import List
from pydantic import BaseModel

router = APIRouter(prefix="/factura", tags=["Factura"])

class ItemEntrada(BaseModel):
    nombre: str
    cantidad: int
    precio_unitario: float

@router.post("/")
def generar_factura(cliente: str, items: List[ItemEntrada]):
    lista_items = [Item(i.nombre, i.cantidad, i.precio_unitario) for i in items]
    gen = GeneradorFactura(DescuentoVIP())
    factura = gen.generar(cliente, lista_items)
    return factura
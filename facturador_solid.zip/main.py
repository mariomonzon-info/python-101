from modelos.factura import Item
from servicios.generador import GeneradorFactura
from servicios.descuento import DescuentoVIP
from servicios.exportador import ExportadorJSON

items = [
    Item("Laptop", 1, 1000),
    Item("Ratón", 2, 25)
]

generador = GeneradorFactura(DescuentoVIP())
factura = generador.generar("Mario Monzón", items)

exportador = ExportadorJSON()
exportador.exportar(factura)
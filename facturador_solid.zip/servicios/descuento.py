from interfaces.i_descuento import IEstrategiaDescuento

class DescuentoVIP(IEstrategiaDescuento):
    def aplicar(self, factura):
        return factura.total * 0.15

class SinDescuento(IEstrategiaDescuento):
    def aplicar(self, factura):
        return 0.0
from interfaces.i_exportador import IExportador
from modelos.factura import Factura
import json

class ExportadorConsola(IExportador):
    def exportar(self, factura: Factura):
        print(f"Factura para {factura.cliente}: Total {factura.total}€")

class ExportadorJSON(IExportador):
    def exportar(self, factura: Factura):
        with open("factura.json", "w") as f:
            json.dump(factura.__dict__, f, indent=2, default=str)
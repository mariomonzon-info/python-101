from modelos.factura import Factura
from interfaces.i_descuento import IEstrategiaDescuento

class GeneradorFactura:
    def __init__(self, estrategia_descuento: IEstrategiaDescuento):
        self.estrategia = estrategia_descuento

    def generar(self, cliente: str, items: list) -> Factura:
        subtotal = sum(i.precio_unitario * i.cantidad for i in items)
        factura = Factura(cliente, items, subtotal, 0.0)
        descuento = self.estrategia.aplicar(factura)
        factura.descuento = descuento
        factura.total = subtotal - descuento
        return factura
# 🧾 facturador_solid

Este es un ejemplo práctico de un sistema de facturación diseñado aplicando los principios SOLID en Python.

## 📁 Estructura

- `modelos/`: define estructuras de datos (Factura, Item)
- `interfaces/`: define contratos abstractos para extensibilidad
- `servicios/`: lógica de negocio desacoplada por responsabilidad
- `main.py`: script principal de ejemplo

## ▶️ Uso

```bash
python main.py
```

Genera una factura con descuento VIP y la exporta a `factura.json`.

## 🔧 Requisitos

- Python 3.10+
- No requiere librerías externas (solo `dataclasses` y `json`)

## ✅ SOLID Aplicado

- **S**: Cada clase hace solo una cosa
- **O**: Nuevas estrategias de descuento sin modificar el código existente
- **L**: Clases `DescuentoVIP`/`SinDescuento` cumplen substitución
- **I**: Interfaces separadas para descuento/exportación
- **D**: Las clases dependen de abstracciones, no implementaciones

---

¿Quieres extenderlo a una API REST con FastAPI o agregar persistencia con SQLite/PostgreSQL?